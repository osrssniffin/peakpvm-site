# S Niffin — OSRS profile

A clean rebuild of the S Niffin profile page. The profile, progress recaps, collection log and pet records are sourced from the public TempleOSRS API. The supplied low-poly portrait is used as the hero artwork.

## Run locally

```bash
npm install
npm run dev
```

## Build for deployment

```bash
npm run build
```

The static production site is generated in `dist/`. Deploy that folder to GitHub Pages, Cloudflare Pages, Netlify or any static host. For GitHub Pages, set the repository's Pages source to GitHub Actions or deploy `dist/` using your preferred workflow.

## Data sources

- `player_info.php` — current profile values and rank data.
- `player_gains.php` — 24-hour, weekly and monthly gains.
- `player_datapoints.php` — historical snapshots for the XP chart.
- `pets/pet_count.php` — Temple's pet ownership and count data.
- `collection-log/player_collection_log.php` — collection log records.

The site refreshes Temple data every five minutes and also has a manual refresh control. TempleOSRS must have a synced player profile and collection log for those sections to populate. Some values may remain blank if Temple does not return them for the account or API response format changes.

## Important notes

- The original page's other sections and styling are intentionally not carried over. Only the concept of **The Menagerie** is retained.
- Pet ownership is taken from Temple pet tracking, not inferred from boss KC.
- Temple's collection log API may return category/item structures that evolve over time; the UI is defensive but should be checked against live API responses after deployment.
- The TempleOSRS overview page itself returned HTTP 403 to the inspection client, so the implementation uses Temple's documented API endpoints rather than scraping the profile HTML.
- The current first pass renders the collection log from the Temple response. Item icon artwork can be added using a verified item image source once you decide which icon set to use.
